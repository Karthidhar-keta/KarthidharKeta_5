package honeywell.coding.challenge.booking.cab.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import honeywell.coding.challenge.booking.cab.models.Cab;
import honeywell.coding.challenge.booking.cab.models.Driver;
import honeywell.coding.challenge.booking.cab.models.Location;
import honeywell.coding.challenge.booking.cab.repositories.CabRepository;

@RestController("/api/v1")
public class BookCab {
	@Autowired
	private CabRepository cabRepo;
	@GetMapping(value = "/getCab")
	public Cab getCab(@RequestParam String city,@RequestParam String ipAddress,@RequestParam String lattitude,@RequestParam String longitude) {
		Location l=new Location(ipAddress,city,lattitude,longitude);
		Cab nearestCab=null;
		Driver driver;
		List<Cab> cabs=cabRepo.findAll();
		for(Cab cab:cabs) {
			Location cabLocation=cab.getLocation();
			Driver d=cab.getDriver();
			//calculate distance if nearest and driver waiting time
			nearestCab=cab;
		}
		return nearestCab;
	}

}
