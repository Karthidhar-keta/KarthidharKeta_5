package honeywell.coding.challenge.booking.cab.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import honeywell.coding.challenge.booking.cab.models.Cab;

public interface CabRepository extends JpaRepository<Cab, Long>{

}
