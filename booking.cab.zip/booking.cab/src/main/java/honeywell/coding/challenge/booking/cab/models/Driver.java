package honeywell.coding.challenge.booking.cab.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Driver {
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private Long waitingTime;
	Driver(){
		
	}
	
	public Driver(String name, Long waitingTime) {
		super();
		this.name = name;
		this.waitingTime = waitingTime;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getWaitingTime() {
		return waitingTime;
	}
	public void setWaitingTime(Long waitingTime) {
		this.waitingTime = waitingTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((waitingTime == null) ? 0 : waitingTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Driver other = (Driver) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (waitingTime == null) {
			if (other.waitingTime != null)
				return false;
		} else if (!waitingTime.equals(other.waitingTime))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Driver [id=" + id + ", name=" + name + ", waitingTime=" + waitingTime + "]";
	}
	
	
	

}
