package honeywell.coding.challenge.booking.cab.repositories;

import java.sql.Driver;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DriverRepository extends JpaRepository<Driver, Long>{

}
